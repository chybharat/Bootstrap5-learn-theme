
//---------- light gallery 2 (new) -------------- 
lightGallery(document.getElementById('gallery'), {
    customSlideName: true,
    licenseKey: 'GPLv3',
    speed: 500,
    download: true,
    rotate: true,
    pager: true,
    captions: true,
    mode: 'lg-zoom-in-out',
    plugins: [lgZoom, lgThumbnail, lgFullscreen], 
    selector: 'a', 
    mobileSettings: {
        controls: false,
        showCloseIcon: true,
        download: true,
        rotate: false
    } 
});


lightGallery(document.getElementById('gallery-videos'), { 
    plugins: [lgVideo, lgAutoplay], 
    selector: 'a',  
});
lightGallery(document.getElementById('single-videos'), {
    download: false,
    plugins: [lgVideo],
    selector: 'a',
});


//----------End light gallery 2 (new) -------------- 